from prog.mEdit import main
